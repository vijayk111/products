import { AbstractControl, ValidationErrors  } from '@angular/forms';


export function PasswordMatch(control: AbstractControl): ValidationErrors  | null {

        const cpwd = control.get('cpassword');  
        const pwd = control.root.get('password');

        console.log(cpwd?.value+ " " +pwd?.value);
        
        if(cpwd?.pristine || pwd?.pristine){
            return null;
        }
        
        if(cpwd?.value != pwd?.value){
            cpwd?.setErrors({mustMatch :true});
        } 
        else{
            cpwd?.setErrors(null);
        }

        return null;
}