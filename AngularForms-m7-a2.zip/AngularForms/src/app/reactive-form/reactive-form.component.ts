import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { PasswordMatch } from './PwdMatch';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {

  regForm : any;
  submitted: boolean = false;
  constructor() {
  }

  ngOnInit(){
    this.initForm();
  }

  private initForm(){   
    this.regForm = new FormGroup({
      fullname : new FormControl("", [Validators.required]),
      email : new FormControl("", [Validators.required, Validators.pattern("^[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]*$")]),
      address : new FormControl("", [Validators.required]),
      city : new FormControl("", [Validators.required]),
      phonenumber : new FormControl("", [Validators.required, Validators.pattern("^[0-9]{10,12}$")]),
      password : new FormControl("", [Validators.required, Validators.minLength(6)]),
      cpassword : new FormControl("", [Validators.required]),
      agree : new FormControl(false, [Validators.requiredTrue])     
    },
    {validators : PasswordMatch}
    );
  } 

  get form() {
    return this.regForm.controls;
  }

  onSubmit(){
    this.submitted = true;
    if (this.regForm.invalid) {
      return;
    }
    console.log(this.regForm.value);
  }
}
