import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from '../productService/product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

 product: any ;
 id : any;
 sub: any;
 imagelink : any;
  constructor(private route:ActivatedRoute, 
    private router:Router, 
    private service:ProductService) {}
 
ngOnInit() {  
    this.id=this.route.snapshot.paramMap.get("id");  
    console.log(this.id);
    this.sub=this.route.paramMap.subscribe(params => { 
      console.log(params); 
       let products=this.service.getProducts();
       this.product=products.find(p => p.id==this.id);    
   });
    console.log(this.product);    
}

onBack() {
  this.router.navigate(['product']);
}

}



