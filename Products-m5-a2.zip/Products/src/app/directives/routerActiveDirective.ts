import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
    selector : '[highlight]'
})

export class RouterDirective {    
   
  @Input() defaultColor: string = 'hsl(0, 0%, 97%)';
  constructor(private el: ElementRef) { }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }
  
  @HostListener('click') onClick() {
    this.highlight(this.defaultColor);
  }
}