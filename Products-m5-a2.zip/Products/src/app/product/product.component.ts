import { Component, OnInit } from '@angular/core';
import { Product } from '../product-details/product';
import { ProductService } from '../productService/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  plist! : Product [] ;

  constructor(private p:ProductService,
    private _router:Router) {    
  }  

  ngOnInit(){
    this.plist = this.p.getProducts();
  }

  goToProduct(id : number){
    this._router.navigate(['/product',id]);
  }

}
