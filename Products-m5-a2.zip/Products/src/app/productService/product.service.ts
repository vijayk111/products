import { Observable } from 'rxjs';
import { Product } from '../product-details/product';
 
 
export class ProductService{
  
    public getProducts() {
 
        let productList: Product[];
 
        productList=[    
            {
              id : 1,
              name : 'Nokia 9 PureView',
              description : '6GB/128GB',
              price : 416,
              img : 'assets/images/nokia.jpg'
            },
            {
              id : 2,
              name : 'Samsung Galaxy S21 Ultra',
              description : '12GB/256GB',
              price : 1099,
              img : 'assets/images/samsung.jpg'
            },
            {
              id : 3,
              name : 'Apple Iphone 12 Pro Max',
              description : '6GB/512GB',
              price : 1300,
              img : 'assets/images/apple.jpg'
            },
            {
              id : 4,
              name : 'Sony Xperia 1 III',
              description : '12GB/256GB',
              price : 1100,
              img : 'assets/images/sony.jpg'
            },
            {
              id : 5,
              name : 'One Plus 9 Pro',
              description : '12GB/512GB',
              price : 1000,
              img : 'assets/images/op.jpg'
            }
          ]
 
        return productList;               
    }
}