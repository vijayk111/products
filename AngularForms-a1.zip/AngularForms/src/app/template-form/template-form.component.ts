import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {

  constructor() { }
  
  fullname : any;
  mail: any;
  phonenumber: any;
  password: any;

  ngOnInit(): void {
  }

  onSubmit(regForm: any) {
    this.fullname = regForm.value.fullname;
    this.mail = regForm.value.mail;
    this.phonenumber = regForm.value.phonenumber;
    this.password = regForm.value.password;
    console.log(regForm.value);
  }
}
