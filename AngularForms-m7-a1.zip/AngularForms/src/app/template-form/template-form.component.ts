import { Component, OnInit } from '@angular/core';
import { User } from './user';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {
  model: User;
  constructor() { 
    this.model = {
      fullname : "",
      email : "",
      phonenumber : "",
      password : "",
      confirmPassword : "",
      agree : ""
    }
  }

  ngOnInit(): void {
  }

  onSubmit(regForm: any) {
    console.log(regForm.value);
    JSON.stringify(this.model);    
  }
}
