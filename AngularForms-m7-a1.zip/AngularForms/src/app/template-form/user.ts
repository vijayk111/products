export class User{
    fullname! : string;
    email! : string;
    phonenumber! : string;
    password! :string;
    confirmPassword! :string;
    agree! : string;
}